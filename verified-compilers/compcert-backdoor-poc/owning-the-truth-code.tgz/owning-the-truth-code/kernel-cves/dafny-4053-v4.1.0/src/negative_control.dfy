method main() {
  assert false;
}
